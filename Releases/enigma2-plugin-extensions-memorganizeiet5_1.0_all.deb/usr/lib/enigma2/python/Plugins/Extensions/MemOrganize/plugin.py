# -*- coding: utf-8 -*-
# Memory Organize Plugin By iet5
# Added Display Name Formatting for Enigma2 Core

import os
import sys
import time
import json
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.Sources.List import List
from Components.config import config, ConfigSubsection, ConfigYesNo, configfile
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from enigma import eTimer
from skin import loadSkin

PLUGIN_PATH = resolveFilename(SCOPE_PLUGINS, "Extensions/MemOrganize/")
DEFAULT_HISTORY_DIRNAME = "MemOrganize"
HISTORY_FILE_NAME = "mem_history.json"
MAX_HISTORY_ITEMS = 300
SNAPSHOT_TOP_COUNT = 20
WHITELIST = ['enigma2', 'init', 'systemd', 'kthreadd', 'rcS', 'sh', 'bash', 'sshd', 'telnetd', 'vsftpd', 'smbd']

config.plugins.MemOrganize = ConfigSubsection()
config.plugins.MemOrganize.run_on_boot = ConfigYesNo(default=False)
config.plugins.MemOrganize.run_in_bg = ConfigYesNo(default=False)

bg_timer = None

try:
    loadSkin(os.path.join(PLUGIN_PATH, "skin.xml"))
except Exception as e:
    print("[MemOrganize] Skin error: %s" % str(e))


PY3 = sys.version_info.major >= 3

def to_unicode(value):
    if PY3:
        if isinstance(value, str):
            return value
        elif isinstance(value, bytes):
            return value.decode('utf-8', 'ignore')
        else:
            return str(value)
    else:
        # Python 2 behavior
        if isinstance(value, unicode):
            return value
        elif isinstance(value, str):
            try:
                return value.decode('utf-8', 'ignore')
            except Exception:
                return str(value)
        else:
            try:
                return str(value).decode('utf-8', 'ignore')
            except Exception:
                return str(value)


def to_display_string(value):
    # Keep Listbox text compatible with both Python 2 and Python 3 images.
    if value is None:
        value = ''
    uval = to_unicode(value)
    if not PY3:
        try:
            return uval.encode('utf-8', 'ignore')
        except Exception:
            return str(uval)
    return str(uval)


def safe_mkdir(path):
    try:
        if not os.path.exists(path):
            os.makedirs(path)
        return os.path.isdir(path)
    except Exception as e:
        print("[MemOrganize] mkdir error for %s: %s" % (path, str(e)))
        return False


def get_candidate_history_roots():
    roots = []
    for candidate in [
        '/media/hdd', '/hdd', '/media/usb', '/media/mmc', '/autofs/sda1', '/autofs/sdb1', '/media/net/hdd'
    ]:
        if candidate not in roots:
            roots.append(candidate)
    return roots


def get_history_paths():
    for root in get_candidate_history_roots():
        try:
            if os.path.isdir(root) and os.access(root, os.W_OK):
                folder = os.path.join(root, DEFAULT_HISTORY_DIRNAME)
                if safe_mkdir(folder):
                    return folder, os.path.join(folder, HISTORY_FILE_NAME)
        except Exception:
            pass
    fallback = '/tmp/%s' % DEFAULT_HISTORY_DIRNAME
    safe_mkdir(fallback)
    return fallback, os.path.join(fallback, HISTORY_FILE_NAME)


def read_json_file(path, default=None):
    if default is None:
        default = {}
    try:
        if os.path.exists(path):
            if PY3:
                f = open(path, 'r', encoding='utf-8')
            else:
                f = open(path, 'r')
            try:
                data = json.load(f)
            finally:
                f.close()
            return data
    except Exception as e:
        print("[MemOrganize] json read error: %s" % str(e))
    return default


def write_json_file(path, data):
    try:
        folder = os.path.dirname(path)
        safe_mkdir(folder)
        tmp = path + '.tmp'
        if PY3:
            f = open(tmp, 'w', encoding='utf-8')
        else:
            f = open(tmp, 'w')
        try:
            json.dump(data, f)
        finally:
            f.close()
        os.rename(tmp, path)
        return True
    except Exception as e:
        print("[MemOrganize] json write error: %s" % str(e))
        return False


def get_proc_name_from_pid(pid):
    try:
        f = open('/proc/%s/status' % pid, 'r')
        try:
            for line in f:
                if line.startswith('Name:'):
                    return line.split()[1].strip()
        finally:
            f.close()
    except Exception:
        pass
    return ''


def get_cmdline_from_pid(pid):
    try:
        f = open('/proc/%s/cmdline' % pid, 'rb')
        try:
            raw = f.read()
        finally:
            f.close()
        if not raw:
            return ''
        raw = raw.replace(b'\x00', b' ').strip()
        return to_unicode(raw)
    except Exception:
        return ''


def get_journal_hint(pid):
    # Use journalctl only when available to expose richer details on images that support it.
    name = get_proc_name_from_pid(pid)
    if not name:
        return ''
    journalctl = '/usr/bin/journalctl'
    if not os.path.exists(journalctl):
        return ''
    try:
        cmd = "%s --no-pager -n 1 _COMM=%s 2>/dev/null" % (journalctl, name)
        pipe = os.popen(cmd)
        try:
            line = pipe.read().strip()
        finally:
            pipe.close()
        return to_unicode(line[:120])
    except Exception:
        return ''


def get_process_ram_mb(pid):
    name = ''
    ram_kb = 0
    try:
        f = open('/proc/%s/status' % pid, 'r')
        try:
            for line in f:
                if line.startswith('Name:'):
                    name = line.split()[1].strip()
                elif line.startswith('VmRSS:'):
                    ram_kb = int(line.split()[1].strip())
        finally:
            f.close()
    except Exception:
        return '', 0
    return name, int(ram_kb / 1024)


def get_enigma2_plugin_memory_mb(pid, total_mb):
    plugin_mb = 0
    details = {}
    smaps_path = '/proc/%s/smaps' % pid
    try:
        if not os.path.exists(smaps_path):
            return 0, {}
        f = open(smaps_path, 'r')
        try:
            current_path = ''
            current_rss = 0
            for raw in f:
                line = raw.strip()
                if not line:
                    continue
                if line.startswith('Rss:'):
                    try:
                        current_rss = int(line.split()[1])
                    except Exception:
                        current_rss = 0
                    if current_path:
                        normalized = current_path.lower()
                        if '/plugins/' in normalized or '/extensions/' in normalized or '/python/plugins/' in normalized:
                            plugin_mb += int(current_rss / 1024)
                            base = os.path.basename(current_path)
                            if not base:
                                base = current_path
                            details[base] = details.get(base, 0) + int(current_rss / 1024)
                elif line[0].isdigit() and '-' in line:
                    parts = line.split()
                    if len(parts) >= 6:
                        current_path = parts[-1]
                    else:
                        current_path = ''
                    current_rss = 0
        finally:
            f.close()
    except Exception as e:
        print("[MemOrganize] smaps parse error: %s" % str(e))
        return 0, {}
    if plugin_mb > total_mb:
        plugin_mb = 0
        details = {}
    return plugin_mb, details


def build_process_entries(include_enigma_split=True):
    temp = []
    try:
        pids = os.listdir('/proc')
    except Exception:
        pids = []
    for pid in pids:
        if not pid.isdigit():
            continue
        name, ram_mb = get_process_ram_mb(pid)
        if ram_mb <= 0:
            continue
        if name == 'enigma2' and include_enigma_split:
            plugin_mb, plugin_details = get_enigma2_plugin_memory_mb(pid, ram_mb)
            core_mb = ram_mb - plugin_mb
            cmdline = get_cmdline_from_pid(pid)
            if plugin_mb > 0:
                if core_mb > 0:
                    temp.append({
                        'name': 'enigma2 Core',
                        'original_name': 'enigma2',
                        'ram': core_mb,
                        'pid': pid,
                        'details': cmdline,
                        'journal': get_journal_hint(pid)
                    })
                detail_parts = []
                top_items = sorted(plugin_details.items(), key=lambda item: item[1], reverse=True)[:5]
                for item_name, item_mb in top_items:
                    detail_parts.append('%s=%dMB' % (item_name, item_mb))
                temp.append({
                    'name': 'enigma2 Plugins',
                    'original_name': 'enigma2_plugins',
                    'ram': plugin_mb,
                    'pid': pid,
                    'details': ', '.join(detail_parts),
                    'journal': get_journal_hint(pid)
                })
            else:
                temp.append({
                    'name': 'enigma2 (Core + Plugins)',
                    'original_name': 'enigma2',
                    'ram': ram_mb,
                    'pid': pid,
                    'details': cmdline,
                    'journal': get_journal_hint(pid)
                })
        else:
            temp.append({
                'name': name,
                'original_name': name,
                'ram': ram_mb,
                'pid': pid,
                'details': get_cmdline_from_pid(pid),
                'journal': get_journal_hint(pid)
            })
    return sorted(temp, key=lambda item: item['ram'], reverse=True)


def load_history_db():
    folder, history_file = get_history_paths()
    data = read_json_file(history_file, default={})
    if not isinstance(data, dict):
        data = {}
    if 'events' not in data or not isinstance(data.get('events'), list):
        data['events'] = []
    data['history_folder'] = folder
    data['history_file'] = history_file
    return data


def save_history_db(data):
    folder, history_file = get_history_paths()
    data['history_folder'] = folder
    data['history_file'] = history_file
    if 'events' not in data or not isinstance(data.get('events'), list):
        data['events'] = []
    data['events'] = data['events'][-MAX_HISTORY_ITEMS:]
    return write_json_file(history_file, data)


def append_history_event(event_type, summary, processes=None, details=''):
    data = load_history_db()
    event = {
        'time': time.strftime('%Y-%m-%d %H:%M:%S'),
        'type': event_type,
        'summary': summary,
        'details': details,
        'processes': processes or []
    }
    data['events'].append(event)
    return save_history_db(data)


def build_snapshot_for_history(reason_text):
    proc_entries = build_process_entries(include_enigma_split=True)[:SNAPSHOT_TOP_COUNT]
    processes = []
    for item in proc_entries:
        processes.append({
            'name': item.get('name', ''),
            'original_name': item.get('original_name', ''),
            'ram': item.get('ram', 0),
            'pid': item.get('pid', ''),
            'details': item.get('details', ''),
            'journal': item.get('journal', '')
        })
    return append_history_event('snapshot', reason_text, processes=processes)


def record_history_background():
    try:
        build_snapshot_for_history('Background tracking snapshot')
    except Exception as e:
        print('[MemOrganize] background record failed: %s' % str(e))


def ensure_bg_timer_running():
    global bg_timer
    if bg_timer is None:
        bg_timer = eTimer()
        try:
            bg_timer.timeout.connect(record_history_background)
        except Exception:
            try:
                bg_timer.callback.append(record_history_background)
            except Exception:
                pass
    try:
        bg_timer.start(60000, False)
    except Exception as e:
        print('[MemOrganize] timer start error: %s' % str(e))


def stop_bg_timer():
    global bg_timer
    try:
        if bg_timer is not None:
            bg_timer.stop()
    except Exception:
        pass


def autostart(reason, **kwargs):
    if reason == 0:
        if config.plugins.MemOrganize.run_on_boot.value:
            build_snapshot_for_history('Boot snapshot')
        if config.plugins.MemOrganize.run_in_bg.value:
            ensure_bg_timer_running()


class FlashUsageScreen(Screen):
    skinName = 'FlashUsageScreen'

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        self['lbl_title'] = Label('Internal Flash Usage')
        self['lbl_fs_root'] = Label('Flash Summary:')
        self['lbl_val_root'] = Label('...')
        self['lbl_fs_data'] = Label('Data Summary:')
        self['lbl_val_data'] = Label('...')
        
        self['lbl_col_name'] = Label('Package / Plugin')
        self['lbl_col_mem'] = Label('Flash Usage')

        self['key_red'] = Label('Back')
        self['key_green'] = Label('Refresh')
        self['key_yellow'] = Label('Root Flash')
        self['key_blue'] = Label('Data Flash')
        self['lbl_help'] = Label('Loading flash data...')

        self.list_data = []
        self['history_list'] = List(self.list_data)

        self['actions'] = ActionMap([
            'ColorActions', 'OkCancelActions', 'DirectionActions', 'MenuActions', 'InfobarMenuActions'
        ],
        {
            'red': self.close,
            'green': self.refresh_log,
            'yellow': self.show_root_flash,
            'blue': self.show_data_flash,
            'cancel': self.close,
            'up': self.move_up,
            'down': self.move_down,
            'left': self.page_up,
            'right': self.page_down,
        }, -1)
        
        self.current_mode = 'root'
        self.onLayoutFinish.append(self.refresh_log)

    def move_up(self):
        self['history_list'].selectPrevious()

    def move_down(self):
        self['history_list'].selectNext()

    def page_up(self):
        for i in range(10):
            self['history_list'].selectPrevious()

    def page_down(self):
        for i in range(10):
            self['history_list'].selectNext()

    def show_root_flash(self):
        self.current_mode = 'root'
        self.refresh_log()

    def show_data_flash(self):
        self.current_mode = 'data'
        self.refresh_log()

    def get_fs_usage(self, path):
        try:
            st = os.statvfs(path)
            total = (st.f_blocks * st.f_frsize)
            free = (st.f_bavail * st.f_frsize)
            used = total - free
            total_gb = total / (1024.0 * 1024.0 * 1024.0)
            used_gb = used / (1024.0 * 1024.0 * 1024.0)
            return "Size: %.2f GB Used: %.2f GB" % (total_gb, used_gb)
        except Exception:
            return "Size: N/A Used: N/A"

    def get_dir_size_mb(self, start_path):
        total_size = 0
        try:
            for dirpath, dirnames, filenames in os.walk(start_path):
                for f in filenames:
                    fp = os.path.join(dirpath, f)
                    if not os.path.islink(fp) and os.path.isfile(fp):
                        total_size += os.path.getsize(fp)
        except Exception:
            pass
        return total_size / (1024.0 * 1024.0)

    def refresh_log(self):
        self.list_data = []

        root_summary = self.get_fs_usage('/')
        self['lbl_val_root'].setText(root_summary)

        data_path = '/data'
        if not os.path.ismount(data_path) and not os.path.exists(data_path):
             data_path = '/media/hdd'
        
        data_summary = self.get_fs_usage(data_path)
        self['lbl_val_data'].setText(data_summary)

        paths_to_scan = []
        if self.current_mode == 'root':
            paths_to_scan = [
                '/usr/lib/enigma2/python/Plugins/Extensions/',
                '/usr/lib/enigma2/python/Plugins/SystemPlugins/'
            ]
            self['lbl_help'].setText('Showing root flash package sizes | Menu/Info/OK opens this screen')
        else:
            paths_to_scan = [
                os.path.join(data_path, 'plugins/'),
                os.path.join(data_path, 'enigma2/'),
                os.path.join(data_path, 'backup/')
            ]
            self['lbl_help'].setText('Showing data flash storage sizes | Menu/Info/OK opens this screen')
            
            empty_count = 0
            for p in paths_to_scan:
                if not os.path.exists(p):
                    empty_count += 1
            if empty_count == len(paths_to_scan) and os.path.exists(data_path):
                paths_to_scan = [data_path]
        
        items = []
        for base_path in paths_to_scan:
            if os.path.exists(base_path):
                try:
                    dirs = os.listdir(base_path)
                except Exception:
                    dirs = []
                for d in dirs:
                    full_path = os.path.join(base_path, d)
                    if os.path.isdir(full_path):
                        if d in ['proc', 'sys', 'dev']:
                             continue
                        size_mb = self.get_dir_size_mb(full_path)
                        if size_mb > 0.01:
                            items.append((d, size_mb))

        items.sort(key=lambda x: x[1], reverse=True)

        for name, size_mb in items:
            size_str = "%.2f MB" % size_mb
            self.list_data.append((('', ''), to_display_string(name), to_display_string(size_str)))

        if not self.list_data:
            self.list_data.append((('', ''), to_display_string('No Extracted Packages Found'), to_display_string('0.00 MB')))

        self['history_list'].updateList(self.list_data)



class MemoryOrganizeScreen(Screen):
    skinName = 'MemoryOrganizeScreen'

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        self['lbl_title'] = Label('Memory Organize By iet5')
        
        version_text = 'Ver Unknown'
        try:
            f = open(os.path.join(PLUGIN_PATH, "Ver.txt"), 'r')
            try:
                v_text = f.read().strip()
                if v_text:
                    if v_text.lower().startswith("ver"):
                        version_text = v_text
                    else:
                        version_text = 'Ver ' + v_text
            finally:
                f.close()
        except Exception:
            pass
            
        self['lbl_version'] = Label(version_text)
        self['lbl_total_ram'] = Label('RAM Total')
        self['lbl_used_ram'] = Label('RAM Used')
        self['lbl_free_ram'] = Label('RAM Free')
        self['lbl_col_name'] = Label('Process / Component')
        self['lbl_col_mem'] = Label('Usage')

        self['key_red'] = Label('Exit')
        self['key_green'] = Label('Refresh')
        self['key_yellow'] = Label('Free Cache')
        self['key_blue'] = Label('Kill')
        self['lbl_help'] = Label('Menu/Info: Flash Usage | Blue: Kill | Red: Exit')

        self.proc_list = []
        self['process_list'] = List(self.proc_list)

        self['actions'] = ActionMap([
            'ColorActions', 'OkCancelActions', 'DirectionActions', 'MenuActions', 'InfobarMenuActions'
        ],
        {
            'red': self.close,
            'green': self.manual_refresh,
            'yellow': self.free_cache,
            'blue': self.clear_process,
            'menu': self.open_history,
            'showMainMenu': self.open_history,
            'info': self.open_history,
            'cancel': self.close,
            'up': self.move_up,
            'down': self.move_down,
            'left': self.page_up,
            'right': self.page_down,
        }, -1)

        self.timer = eTimer()
        try:
            self.timer.timeout.connect(self.update_screen)
        except Exception:
            self.timer.callback.append(self.update_screen)
        self.timer.start(3000, False)
        self.onLayoutFinish.append(self.manual_refresh)

    def move_up(self):
        self['process_list'].selectPrevious()

    def move_down(self):
        self['process_list'].selectNext()

    def page_up(self):
        for i in range(10):
            self['process_list'].selectPrevious()

    def page_down(self):
        for i in range(10):
            self['process_list'].selectNext()

    def open_history(self):
        try:
            self.timer.stop()
        except Exception:
            pass
        self.session.openWithCallback(self.on_history_closed, FlashUsageScreen)

    def on_history_closed(self, *args):
        try:
            self.timer.start(3000, False)
        except Exception:
            pass
        self.update_screen()

    def manual_refresh(self):
        self.update_screen()
        build_snapshot_for_history('Manual refresh snapshot')
        self['lbl_help'].setText('Refresh completed and written to disk')

    def update_screen(self):
        self.update_stats()
        self.update_list()

    def update_stats(self):
        mem = {}
        try:
            f = open('/proc/meminfo', 'r')
            try:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 2:
                        mem[parts[0]] = int(parts[1])
            finally:
                f.close()
            mem_total = mem.get('MemTotal:', 0)
            mem_free = mem.get('MemFree:', 0)
            mem_buffers = mem.get('Buffers:', 0)
            mem_cached = mem.get('Cached:', 0)
            used = mem_total - (mem_free + mem_buffers + mem_cached)
            self['lbl_total_ram'].setText('Total: %d MB' % int(mem_total / 1024))
            self['lbl_used_ram'].setText('Used: %d MB' % int(used / 1024))
            self['lbl_free_ram'].setText('Free: %d MB' % int((mem_total - used) / 1024))
        except Exception as e:
            print('[MemOrganize] meminfo error: %s' % str(e))

    def update_list(self):
        temp = build_process_entries(include_enigma_split=True)
        self.proc_list = []
        for i in temp:
            # Main screen shows RAM usage only to keep the list clean on TVs and low-width skins.
            # Detailed cmdline/journal information remains available for history records on the second screen.
            info = '%d MB' % int(i.get('ram', 0))
            self.proc_list.append(((i.get('pid', ''), i.get('original_name', '')), to_display_string(i.get('name', '-')), to_display_string(info)))
        self['process_list'].updateList(self.proc_list)

    def free_cache(self):
        ret = os.system('sync; echo 3 > /proc/sys/vm/drop_caches')
        self.update_screen()
        if ret == 0:
            append_history_event('action', 'Free cache executed', details='sync; echo 3 > /proc/sys/vm/drop_caches')
            build_snapshot_for_history('Snapshot after Free Cache')
            self['lbl_help'].setText('Free Cache command executed')
        else:
            append_history_event('error', 'Free cache failed', details='Command returned=%s' % str(ret))
            self['lbl_help'].setText('Free Cache failed or permission denied')

    def clear_process(self):
        sel = self['process_list'].getCurrent()
        if sel:
            pid, original_name = sel[0]
            if original_name in WHITELIST:
                self.session.open(MessageBox, 'SYSTEM PROTECTED: ' + original_name, MessageBox.TYPE_INFO)
                return
            self.target_pid = pid
            self.target_name = original_name
            self.session.openWithCallback(self.kill_it, MessageBox, 'Kill ' + original_name + '?', MessageBox.TYPE_YESNO)

    def kill_it(self, res):
        if res:
            ret = os.system('kill -9 ' + str(self.target_pid))
            append_history_event('action', 'Kill process request', details='%s pid=%s result=%s' % (self.target_name, str(self.target_pid), str(ret)))
            self.update_screen()
            self['lbl_help'].setText('Kill command sent to %s' % self.target_name)


def main(session, **kwargs):
    session.open(MemoryOrganizeScreen)


def menu(menuid, **kwargs):
    return [('Memory Organize', main, 'mem_org_main', 1)] if menuid == 'mainmenu' else []


def Plugins(**kwargs):
    return [
        PluginDescriptor(where=PluginDescriptor.WHERE_AUTOSTART, fnc=autostart),
        PluginDescriptor(name='Memory Organize', description='Manage RAM', icon='plugin.png', where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main),
        PluginDescriptor(name='Memory Organize', description='Manage RAM', where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main),
        PluginDescriptor(name='Memory Organize', description='Manage RAM', where=PluginDescriptor.WHERE_MENU, fnc=menu)
    ]
